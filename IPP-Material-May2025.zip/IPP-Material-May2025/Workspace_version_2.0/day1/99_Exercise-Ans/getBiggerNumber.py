def getBiggerNumber(num1, num2):
	if num1 > num2:
		return num1
	else:
		return num2